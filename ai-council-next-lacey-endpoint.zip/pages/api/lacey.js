export default async function handler(req, res) {
  const sharedSecret = process.env.SHARED_SECRET;
  const clientKey = req.headers['x-ai-council-key'];

  if (sharedSecret && clientKey !== sharedSecret) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  res.status(200).json({ message: 'Lacey endpoint is working!' });
}
